package com.cognizant.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


	@Entity
	@Table(name="vendor")
public class Vendor{
		@Id
		@Column(name="vendor_id")
		private String vendor_userame;
		@Column(name="password")
		private String vendor_password;
		
		public Vendor(){}

		public String getVendor_userame() {
			return vendor_userame;
		}

		public void setVendor_userame(String vendor_userame) {
			this.vendor_userame = vendor_userame;
		}

		public String getVendor_password() {
			return vendor_password;
		}

		public void setVendor_password(String vendor_password) {
			this.vendor_password = vendor_password;
		}

		
		

	}
