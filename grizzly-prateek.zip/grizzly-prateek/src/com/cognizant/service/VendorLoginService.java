package com.cognizant.service;

import com.cognizant.entity.Vendor;

public interface VendorLoginService {

	public boolean doVendorLogin(Vendor vendor);
}
