package com.cognizant.dao;

import com.cognizant.entity.Vendor;

public interface VendorLoginDAO {

	 public boolean doVendorLogin(Vendor vendor);
}
