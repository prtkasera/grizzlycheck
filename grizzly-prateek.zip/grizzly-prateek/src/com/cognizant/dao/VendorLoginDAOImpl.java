package com.cognizant.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cognizant.entity.Vendor;

@Repository("VendorLoginDAOImpl")
public class VendorLoginDAOImpl implements VendorLoginDAO{
@Autowired
SessionFactory sessionfactory;
	@Override
	public boolean doVendorLogin(Vendor vendor) {
		Session session=sessionfactory.openSession();
		// TODO Auto-generated method stub
		Query query=session.createQuery("select o from vendor where o.vendor_username=:username and o.vendor_password=:password"); 
		query.setParameter("username", vendor.getVendor_userame());
		query.setParameter("password", vendor.getVendor_password());
		List<Vendor> vendorlist=query.list();
		if(vendorlist.isEmpty())
		{
			return false;
		}
		else
		{
		return true;
	}
	}
}
