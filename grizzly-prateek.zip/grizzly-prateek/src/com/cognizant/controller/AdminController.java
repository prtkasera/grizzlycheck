package com.cognizant.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cognizant.entity.Admin;
import com.cognizant.entity.Product;
import com.cognizant.entity.Vendor;
//import com.cognizant.service.AdminLoginService;
import com.cognizant.service.ProductService;

@Controller
public class AdminController {
	@Autowired
	private ProductService productService;
	
	@Autowired@Qualifier("ProductValidator")
	private Validator productvalidator;
	
	@Autowired@Qualifier("AdminValidator")
	private Validator adminvalidator;
	
	@Autowired@Qualifier("VendorValidator")
	private Validator vendorvalidator;
	

	
	
	@RequestMapping(value="productForm.htm",method=RequestMethod.GET)
	public String loadProductForm(){
		return "productform";
	}
	@RequestMapping(value="addproduct.htm",method=RequestMethod.POST)
	public ModelAndView persistProduct(@ModelAttribute("product")Product product,Errors errors){
		
		ModelAndView mv=new ModelAndView();

		ValidationUtils.invokeValidator(productvalidator, product, errors);
		if(errors.hasErrors()){
			mv.setViewName("productform");
		}else{
		boolean productPersist=productService.persistProduct(product);
		
		if(productPersist){
			mv.addObject("status","Product successfully registered");
		}else{
			mv.addObject("status","Product registration failed");
		}

		mv.setViewName("productform");
		}
		return mv;
	}
	
	
	@ModelAttribute("product")
	public Product createCommandObject(){
		Product product=new Product();
		product.setProductId(0);
		product.setProductName("Please type product name");
		product.setProductDescription("Please describe product");
		product.setProductPrice(0.0);
		return product;
	}
	@ModelAttribute("admin")
	public Admin createAdminObject(){
		Admin admin=new Admin();
		return admin;
		
	}
	@ModelAttribute("categoryList")
	public List<String> createProductCategory(){
		return productService.getProductCategoryNames();
	}
	
	@RequestMapping(value="AdminLogin.htm",method=RequestMethod.GET)
	public String loadAdminLoginForm(){
		return "adminlogin";
	}
	@RequestMapping(value="doAdminLogin.htm",method=RequestMethod.POST)
	public ModelAndView doLogin(@ModelAttribute("admin") Admin admin,Errors errors){
		
		ValidationUtils.invokeValidator(adminvalidator, admin, errors);
		ModelAndView mv=new ModelAndView();
		if(errors.hasErrors()){
			mv.setViewName("adminlogin");
		}else
		{
			List<Product> productList=productService.getAllProducts();
			mv.addObject("productList",productList);
			mv.setViewName("viewproducts");
		}
		return mv;
	}
	@RequestMapping(value="VendorLogin.htm",method=RequestMethod.GET)
	public String loadVendorLoginForm(){
		return "vendorlogin";
	}
	@RequestMapping(value="doVendorLogin.htm",method=RequestMethod.POST)
	public ModelAndView doVendorLogin(@ModelAttribute("vendor") Vendor vendor,Errors errors){
		
		ValidationUtils.invokeValidator(vendorvalidator, vendor, errors);
		ModelAndView mv=new ModelAndView();
		if(errors.hasErrors()){
			mv.setViewName("vendorlogin");
		}
		else
		{
			
		}
		return mv;

}
}
